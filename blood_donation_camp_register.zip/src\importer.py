"""
Bulk CSV Dataset Importer with Schema Checks and Row-by-Row Error Logging.
"""

import csv
import datetime
from pathlib import Path
from typing import List, Tuple, Dict, Any, Optional
from .models import DonorRecord, BloodGroup, DonorStatus
from .validators import (
    validate_name, validate_age, validate_gender, validate_blood_group,
    validate_phone, validate_weight, validate_hemoglobin, evaluate_donor_eligibility
)


EXPECTED_HEADERS = {
    "name", "age", "gender", "blood_group", "phone", "weight_kg", "hemoglobin_g_dl"
}


class BulkCSVImporter:
    """Ingests legacy and external CSV files with defensive sanitization."""

    @staticmethod
    def import_from_csv(
        file_path: str,
        existing_donors: List[DonorRecord],
        logs_dir: Optional[Path] = None
    ) -> Tuple[List[DonorRecord], int, Optional[Path], List[str]]:
        """
        Reads a CSV file, performs schema check and row-by-row validation.
        Returns:
            (valid_new_donors, failure_count, error_log_path_or_None, summary_messages)
        """
        path = Path(file_path)
        if not path.exists():
            return [], 0, None, [f"Error: Target file '{file_path}' does not exist."]

        if logs_dir is None:
            logs_dir = path.parent

        today_str = datetime.datetime.now().strftime("%Y%m%d")
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        error_log_path = logs_dir / f"bulk_import_errors_{timestamp}.log"

        new_records: List[DonorRecord] = []
        error_log_entries: List[str] = []
        row_failures = 0

        # Calculate base ID sequence
        prefix = f"DON-{today_str}-"
        highest_seq = 0
        for r in existing_donors:
            if r.donor_id.startswith(prefix):
                try:
                    seq_num = int(r.donor_id.replace(prefix, ""))
                    if seq_num > highest_seq:
                        highest_seq = seq_num
                except ValueError:
                    pass

        try:
            with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
                reader = csv.DictReader(f)
                if not reader.fieldnames:
                    return [], 0, None, ["Error: CSV file is empty or has no header row."]

                # Case-insensitive header matching
                header_map = {col.strip().lower(): col for col in reader.fieldnames}
                missing_headers = [req for req in EXPECTED_HEADERS if req not in header_map]

                if missing_headers:
                    return [], 0, None, [
                        f"Schema Validation Failed: Missing required columns: {', '.join(missing_headers)}. "
                        f"Expected headers: {', '.join(sorted(EXPECTED_HEADERS))}"
                    ]

                for row_idx, raw_row in enumerate(reader, start=2):  # line 2 is first data row
                    row_errors = []

                    # 1. Name
                    raw_name = raw_row.get(header_map["name"], "")
                    valid_name, name_res = validate_name(raw_name)
                    if not valid_name:
                        row_errors.append(f"Name: {name_res}")

                    # 2. Age
                    raw_age = raw_row.get(header_map["age"], "")
                    valid_age, age_err, age_val = validate_age(raw_age)
                    if not valid_age:
                        row_errors.append(f"Age: {age_err}")

                    # 3. Gender
                    raw_gender = raw_row.get(header_map["gender"], "")
                    valid_gender, gender_res = validate_gender(raw_gender)
                    if not valid_gender:
                        row_errors.append(f"Gender: {gender_res}")

                    # 4. Blood Group
                    raw_bg = raw_row.get(header_map["blood_group"], "")
                    valid_bg, bg_res = validate_blood_group(raw_bg)
                    if not valid_bg:
                        row_errors.append(f"Blood Group: {bg_res}")

                    # 5. Phone
                    raw_phone = raw_row.get(header_map["phone"], "")
                    valid_phone, phone_res = validate_phone(raw_phone)
                    if not valid_phone:
                        row_errors.append(f"Phone: {phone_res}")

                    # 6. Weight
                    raw_weight = raw_row.get(header_map["weight_kg"], "")
                    valid_weight, weight_err, weight_val = validate_weight(raw_weight)
                    if not valid_weight:
                        row_errors.append(f"Weight: {weight_err}")

                    # 7. Hemoglobin
                    raw_hb = raw_row.get(header_map["hemoglobin_g_dl"], "")
                    valid_hb, hb_err, hb_val = validate_hemoglobin(raw_hb)
                    if not valid_hb:
                        row_errors.append(f"Hemoglobin: {hb_err}")

                    # If row has validation errors, log and continue
                    if row_errors:
                        row_failures += 1
                        error_log_entries.append(
                            f"Row {row_idx} [Raw: {raw_name} | {raw_bg} | {raw_phone}]: {', '.join(row_errors)}"
                        )
                        continue

                    # Evaluate clinical eligibility
                    status, defer_reason = evaluate_donor_eligibility(age_val, weight_val, hb_val)

                    # Optional fields from CSV if present
                    donor_id_col = header_map.get("donor_id")
                    given_id = raw_row.get(donor_id_col, "").strip() if donor_id_col else ""
                    if not given_id:
                        highest_seq += 1
                        given_id = f"{prefix}{highest_seq:04d}"

                    reg_date_col = header_map.get("registration_date")
                    reg_date = (
                        raw_row.get(reg_date_col, "").strip()
                        if reg_date_col and raw_row.get(reg_date_col)
                        else datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    )

                    status_col = header_map.get("status")
                    if status_col and raw_row.get(status_col):
                        user_status = raw_row.get(status_col).strip().capitalize()
                        if user_status in DonorStatus.values():
                            status = user_status

                    units_col = header_map.get("units_donated")
                    units = 0
                    if units_col and raw_row.get(units_col):
                        try:
                            units = int(raw_row.get(units_col))
                        except ValueError:
                            units = 0

                    record = DonorRecord(
                        donor_id=given_id,
                        name=name_res,
                        age=age_val,
                        gender=gender_res,
                        blood_group=bg_res,
                        phone=phone_res,
                        weight_kg=weight_val,
                        hemoglobin_g_dl=hb_val,
                        registration_date=reg_date,
                        status=status,
                        deferral_reason=defer_reason,
                        units_donated=units
                    )
                    new_records.append(record)

        except Exception as e:
            return [], 0, None, [f"Critical file reading error: {str(e)}"]

        written_log_path = None
        if error_log_entries:
            try:
                with open(error_log_path, "w", encoding="utf-8") as lf:
                    lf.write(f"=== Blood Donation Camp Register Bulk Import Error Log ===\n")
                    lf.write(f"Source File: {path.resolve()}\n")
                    lf.write(f"Processed At: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    lf.write(f"Total Failed Rows: {row_failures}\n")
                    lf.write("-" * 60 + "\n\n")
                    for err in error_log_entries:
                        lf.write(f"{err}\n")
                written_log_path = error_log_path
            except OSError:
                pass

        summary_msg = [
            f"Successfully processed CSV file.",
            f"Valid Records Parsed: {len(new_records)}",
            f"Rejected Rows: {row_failures}"
        ]
        if written_log_path:
            summary_msg.append(f"Detailed error audit log generated at: {written_log_path.name}")

        return new_records, row_failures, written_log_path, summary_msg
