# 📚 API Reference — Blood Donation Camp Register & Analytics Engine

This document provides the complete programmatic API reference for all internal modules in `src/`, as well as the CLI (`main.py`) and Streamlit Web UI (`app_streamlit.py`) entrypoints.

---

## 1. Domain Models (`src/models.py`)

### `class BloodGroup(str, Enum)`
Validates and enumerates the 8 standard ABO/Rh blood groups:
`A+`, `A-`, `B+`, `B-`, `AB+`, `AB-`, `O+`, `O-`.
- `BloodGroup.values() -> List[str]`: Returns all 8 valid group strings.
- `BloodGroup.is_valid(group_str: str) -> bool`: Case-insensitive membership check.

### `class DonorStatus(str, Enum)`
Operational lifecycle states: `Eligible`, `Deferred`, `Donated`.

### `@dataclass class DonorRecord`
Core entity modeling a volunteer registration.
- **Fields:** `donor_id`, `name`, `age`, `gender`, `blood_group`, `phone`, `weight_kg`, `hemoglobin_g_dl`, `registration_date`, `status`, `deferral_reason`, `units_donated`.
- `to_dict() -> Dict[str, Any]`: Serializes record to JSON/CSV-compatible dictionary.
- `from_dict(data: Dict[str, Any]) -> DonorRecord`: Deserializes with safe type coercion.

---

## 2. Defensive Validation (`src/validators.py`)

| Function | Signature | Description |
|:---|:---|:---|
| `validate_name` | `(name: str) -> Tuple[bool, str]` | Enforces 2–50 alphabetic/space/hyphen characters. |
| `validate_age` | `(age_val: Any) -> Tuple[bool, str, int]` | Parses integer and checks physiological bounds (1–120). |
| `validate_gender` | `(gender_val: str) -> Tuple[bool, str]` | Normalizes `M/F/O` or `Male/Female/Other`. |
| `validate_blood_group` | `(bg_str: str) -> Tuple[bool, str]` | Validates against `BloodGroup.values()`. |
| `validate_phone` | `(phone_str: str) -> Tuple[bool, str]` | Strips `+91`/leading `0`/hyphens and enforces 10 digits. |
| `validate_weight` | `(weight_val: Any) -> Tuple[bool, str, float]` | Checks numeric range (20.0–300.0 kg). |
| `validate_hemoglobin` | `(hb_val: Any) -> Tuple[bool, str, float]` | Checks numeric range (3.0–25.0 g/dL). |
| `evaluate_donor_eligibility` | `(age: int, weight_kg: float, hemoglobin_g_dl: float) -> Tuple[str, str]` | Enforces WHO/AABB clinical limits ($18\le \text{age} \le 65$, $\text{wt}\ge 50\text{ kg}$, $\text{Hb}\ge 12.5\text{ g/dL}$). |
| `prompt_text` | `(prompt_msg, validator, allow_cancel=True)` | Crash-proof terminal input loop for text. |
| `prompt_numeric` | `(prompt_msg, validator, allow_cancel=True)` | Crash-proof terminal input loop for numeric fields. |

---

## 3. Thread-Safe & Indexed Storage (`src/storage.py`)

### `class StorageManager(data_dir: Optional[str] = None)`
Manages concurrent-safe persistence across JSON, CSV, and an indexed SQLite mirror (`donors_index.db`).

- `_acquire_lock()`: Context manager combining `threading.RLock()` and OS-level advisory locking (`msvcrt.locking` on Windows / `fcntl.flock` on POSIX).
- `load_all_donors() -> Tuple[List[DonorRecord], Optional[str]]`: Loads records from `donors.json`. On `JSONDecodeError` or schema corruption, archives the damaged file to `donors_corrupt_<timestamp>.json.bak`, re-initializes clean storage, and returns a recovery warning.
- `save_all_donors(records: List[DonorRecord]) -> bool`: Writes atomically via temporary file + `os.replace()`, syncs `donors.csv`, and updates SQLite indexes.
- `query_indexed(blood_group=None, status=None, phone=None) -> List[DonorRecord]`: Executes $O(\log N)$ B-Tree indexed SQLite queries on `idx_donors_bg`, `idx_donors_status`, and `idx_donors_phone`.
- `generate_next_donor_id(existing_records: List[DonorRecord]) -> str`: Generates sequential `DON-YYYYMMDD-####` IDs.
- `log_audit(action: str, details: str) -> None`: Appends timestamped entries to `audit_log.txt`.

---

## 4. Business Logic, Indexing & Allocation (`src/business_logic.py`)

### `class CampAnalyticsEngine`
- `get_counts_by_blood_group(records) -> Dict[str, Dict[str, int]]`: Tallies `total`, `eligible`, `donated`, `deferred`, and `units` per blood group.
- `compute_camp_summary(records) -> Dict[str, Any]`: Computes rates (`eligibility_rate_pct`, `deferral_rate_pct`, `donation_completion_rate_pct`), clinical means, gender breakdown, and top 3 deferral reasons.
- `evaluate_threshold_warnings(records) -> List[Dict[str, str]]`: Evaluates $O^-$ universal donor deficits, rare negative shortages (`AB-`, `B-`, `A-`), and high deferral rates ($\ge 25\%$).

### `class RecordSearchFilter`
- `filter_records(records, keyword=None, blood_group=None, status=None, min_age=None, max_age=None) -> List[DonorRecord]`

### `class IndexedDonorCache(records: List[DonorRecord])`
$O(1)$ in-memory hash index for instant lookups:
- `get_by_id(donor_id: str) -> Optional[DonorRecord]`
- `get_by_phone(phone: str) -> List[DonorRecord]`
- `get_by_blood_group(blood_group: str) -> List[DonorRecord]`

### `class BloodAllocationOptimizer`
- `allocate_units(records, recipient_group, units_needed, include_pending_eligible=False) -> Dict[str, Any]`: Computes an optimal red-cell allocation plan in conservation priority order (exact match first; `O-` universal donor reserved strictly as last resort).

---

## 5. Bulk CSV Importer & Multi-Format Exporters

- **`BulkCSVImporter.import_from_csv(file_path, existing_donors, logs_dir=None)`** (`src/importer.py`): Schema-checks headers, validates every row, and outputs `bulk_import_errors_*.log` for rejected rows.
- **`CampReportExporter.export_to_markdown(records, output_path)`** (`src/exporters.py`): Generates a formatted Markdown executive briefing.
- **`CampReportExporter.export_to_csv(records, output_path)`** (`src/exporters.py`): Exports standardized CSV.
