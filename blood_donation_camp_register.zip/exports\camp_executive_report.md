# Blood Donation Camp Executive Register Report
**GreenFuture Hack | Domain: Safety & Community | Project #73**
*Generated on: 2026-11-24 09:10:36*

---

## 1. Executive Performance Summary

| Metric | Value |
|:---|:---|
| **Total Registrations** | `38` donors |
| **Eligible Donors** | `18` donors |
| **Completed Donations** | `15` donors |
| **Medically Deferred** | `5` donors |
| **Total Blood Units Collected** | **`15` Units** |
| **Eligibility Rate** | `86.8%` |
| **Deferral Rate** | `13.2%` |
| **Donation Conversion Rate** | `45.5%` |

## 2. Clinical Averages & Donor Demographics

- **Mean Age:** `31.4` years
- **Mean Weight:** `63.5` kg
- **Mean Hemoglobin:** `13.8` g/dL
- **Gender Distribution:** Male: 20, Female: 17, Other: 1

## 3. Blood Group Distribution & Inventory Status

| Blood Group | Total Registered | Eligible | Donated | Deferred | Units Collected | Inventory Status |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| `A+` | 9 | 5 | 2 | 2 | 2 | 🟢 ADEQUATE |
| `A-` | 3 | 3 | 0 | 0 | 0 | 🟢 ADEQUATE |
| `B+` | 6 | 3 | 2 | 1 | 2 | 🟢 ADEQUATE |
| `B-` | 3 | 2 | 1 | 0 | 1 | 🟢 ADEQUATE |
| `AB+` | 4 | 2 | 1 | 1 | 1 | 🟢 ADEQUATE |
| `AB-` | 2 | 2 | 0 | 0 | 0 | 🟢 ADEQUATE |
| `O+` | 8 | 0 | 7 | 1 | 7 | 🟢 ADEQUATE |
| `O-` | 3 | 1 | 2 | 0 | 2 | 🟢 ADEQUATE |

## 4. Active Threshold Warnings & Clinical Insights

> 🟢 **All inventory and eligibility metrics are within standard operational limits.**

### Primary Deferral Drivers

- **Underage: 17 yrs (minimum 18 yrs required)**: 2 donor(s)
- **Overage: 68 yrs (maximum 65 yrs allowed)**: 1 donor(s)
- **Underweight: 46.5 kg (minimum 50.0 kg required)**: 1 donor(s)

---
*Report compiled automatically by Blood Donation Camp Register (Project #73).*