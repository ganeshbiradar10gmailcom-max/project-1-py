# 🩸 Blood Donation Camp Register & Analytics Engine
**GreenFuture Hack | Project #73 | Domain: Safety & Community**  
*A robust, zero-dependency Python application engineered for community blood donation drives.*

---

## 🌟 Executive Overview

In community healthcare drives and academic donation camps, organizers routinely face friction: misplaced paper forms, calculation mistakes in blood inventory counts, delayed insight into critical group shortages (especially universal $O^-$ and rare negative groups), and crashes caused by bad terminal input.

**Blood Donation Camp Register** is a production-grade, zero-external-dependency utility built using **Python 3.10+ Standard Library**. It delivers:
- **Strict Defensive Validation:** Real-time sanitization, regex matching, and medical threshold checks for age, weight, and hemoglobin.
- **Automated Clinical Eligibility Decisions:** Instantly screens candidates against clinical criteria ($18 \le \text{age} \le 65$, $\ge 50.0\text{ kg}$, $\ge 12.5\text{ g/dL}$ Hb) with specific medical rationale for deferrals.
- **Inventory & Shortage Early Warning Engine:** Automated alerts for critical universal donor deficits ($O^-$), negative-group deficiencies, and high deferral rates.
- **Self-Healing Persistence:** Atomic writes and automated corrupted file detection with timestamped recovery archives (`.bak`).
- **Bulk CSV Ingestion:** Fault-tolerant CSV loader that validates line-by-line and generates an error audit log for malformed records.
- **Multi-Format Export:** Generates executive Markdown briefing documents, standardized CSV datasets, and local audit logs.

---

## 🏗️ Architecture & Module Organization

```text
blood_donation_camp_register/
│
├── main.py                         # Application CLI & interactive dispatch loop
├── README.md                       # Comprehensive documentation & demo guide
│
├── src/
│   ├── __init__.py                 # Package declaration & version metadata
│   ├── models.py                   # Dataclasses & Enums (DonorRecord, BloodGroup, DonorStatus)
│   ├── validators.py               # Sanitization, boundary checks, and safe input loop wrappers
│   ├── storage.py                  # Resilient JSON/CSV persistence, atomic writes & corruption recovery
│   ├── business_logic.py           # Blood group aggregations, KPI calculations & shortage alerts
│   ├── importer.py                 # Bulk CSV ingestion with schema validation & row-by-row error logs
│   ├── exporters.py                # Executive Markdown, CSV, and plain-text audit log generators
│   └── ui.py                       # Terminal formatting, ANSI colors, ASCII boxed tables & pagination
│
├── data/
│   ├── donors.json                 # Primary JSON data store (pre-seeded with 35 realistic records)
│   ├── donors.csv                  # Real-time synced CSV mirror
│   ├── sample_donors_seed.csv      # Seed dataset with 38 valid + 4 edge-case invalid rows for demo
│   └── audit_log.txt               # Chronological audit log of all camp transactions
│
├── exports/                        # Auto-generated target directory for exported reports and logs
│   ├── camp_executive_report.md    # Formatted Markdown report
│   ├── donors_standardized_export.csv
│   └── bulk_import_errors_*.log    # Row-by-row error logs from bulk import
│
└── tests/
    └── test_core.py                # Unittest suite covering validation, storage, and analytics
```

---

## 🚀 Quickstart & Setup

### Prerequisites
* **Python 3.10+** (Standard Library only — **no `pip install` required!**)

### Running the Application

1. Open your terminal and navigate to the project directory:
   ```bash
   cd C:\Users\ganap\.gemini\antigravity\scratch\blood_donation_camp_register
   ```

2. Launch the application:
   ```bash
   python main.py
   ```

3. To execute the automated test suite:
   ```bash
   python -m unittest tests/test_core.py
   ```

---

## 🎯 5-Minute Hackathon Demo Script

Follow this step-by-step walkthrough to showcase every must-have and stretch feature during your hackathon presentation:

### Step 1: Launch & Brand Experience
* Run `python main.py`.
* Show the clean branded banner, loaded records count (35 pre-seeded donors), and structured navigation menu.

### Step 2: Demonstrate Defensive Validation & Medical Screening
* Select `[1] Register New Donor`.
* **Demonstrate defensive error handling:**
  * At *Enter Full Name*, type `John123` or empty string $\rightarrow$ Show validation message: *"Donor name must contain only letters..."*.
  * At *Enter Age*, type `seventeen` or `15` $\rightarrow$ Show range & type checking.
  * Enter valid data with a deliberate medical deferral:
    * Name: `Anil Kumar`
    * Age: `24`
    * Gender: `Male`
    * Blood Group: `O-`
    * Phone: `9811223399`
    * Weight: `46.5` *(Underweight threshold < 50kg)*
    * Hemoglobin: `11.8` *(Low hemoglobin threshold < 12.5 g/dL)*
* **Observe the automated decision:** The system detects clinical disqualifiers, flags the donor as **`[Deferred]`**, and outputs the exact reasons: `Underweight: 46.5 kg; Low Hemoglobin: 11.8 g/dL`.

### Step 3: View Real-Time Analytics & Blood Group Breakdown
* Select `[5] View Camp Analytics & Blood Group Breakdown`.
* Walk the judges through:
  * Top KPI Summary (Total Registered, Completed Donors, Deferral %, Average Age, Hemoglobin).
  * The **Blood Group Distribution Table** showing counts for all 8 groups ($A^+, A^-, B^+, B^-, AB^+, AB^-, O^+, O^-$).
  * Deferral drivers breakdown.

### Step 4: Check Early Warning Indicators
* Select `[6] Evaluate Inventory Shortages & Safety Warnings`.
* Show how the engine dynamically computes supply risk:
  * Flags shortage warnings if universal donor ($O^-$) or rare groups ($AB^-, B^-$) fall below safe thresholds.

### Step 5: Test Bulk CSV Ingestion with Row Error Logging
* Select `[8] Bulk CSV Dataset Ingestion`.
* Press `Enter` to use the default `data/sample_donors_seed.csv`.
* Show that the importer successfully ingests valid rows while rejecting 4 deliberately malformed test entries (invalid blood group, bad phone format, negative weight, non-numeric age).
* Highlight that a detailed file `exports/bulk_import_errors_*.log` was automatically generated with line numbers and reasons.

### Step 6: Multi-Format Report Export & Audit Trail
* Select `[7] Multi-Format Report Export`.
* Open `exports/camp_executive_report.md` in any markdown viewer to show the publication-ready executive briefing.
* Point out `data/audit_log.txt` demonstrating security and audit traceability.

### Step 7: Prove State Persistence
* Select `[0] Exit Application`.
* Re-launch with `python main.py`.
* Notice that all registrations, collections, and counters have persisted perfectly across restarts.

---

## 🛡️ Medical Eligibility Standards Enforced

| Parameter | Clinical Safety Requirement | Deferral Classification |
|:---|:---|:---|
| **Donor Age** | $18 \le \text{Age} \le 65$ years | Temporary Deferral (Underage / Overage) |
| **Donor Weight** | $\ge 50.0\text{ kg}$ | Temporary Deferral (Volume safety limit) |
| **Hemoglobin** | $\ge 12.5\text{ g/dL}$ | Temporary Deferral (Prevents donor anemia) |
| **Phone Format** | 10-digit numeric format | Input rejection |
| **Blood Groups** | $A^+, A^-, B^+, B^-, AB^+, AB^-, O^+, O^-$ | Input rejection |

---

## 🏆 Hackathon Mentor Checklist Compliance

- [x] **Interactive Terminal Interface**: Menu-driven CLI with ANSI formatting and pagination.
- [x] **Defensive Input Validation**: Centralized safe input wrappers preventing crashes on blank/non-numeric input.
- [x] **Core Business Logic Engine**: Count by blood group and clinical eligibility engine.
- [x] **Local Data Persistence**: Dual JSON/CSV storage with corrupted file auto-recovery.
- [x] **Record Query & Search**: Filtering by Blood Group, Status, Age Range, and keyword search.
- [x] **Executive Summary Generation**: Comprehensive KPIs, demographic averages, and trends.
- [x] **Stretch: Multi-Format Export**: Markdown executive report, CSV export, and timestamped audit logs.
- [x] **Stretch: Early Warning Indicators**: Alerts for low $O^-$ inventory and rare group deficits.
- [x] **Stretch: Bulk CSV Ingestion**: Schema verification with row-by-row error logs.
- [x] **Zero Dependencies**: Pure Python 3 Standard Library.
