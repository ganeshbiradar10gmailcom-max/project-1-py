"""
Blood Donation Camp Register (Project #73)
Domain: Safety & Community
Hackathon Edition - Zero External Dependencies
"""

__version__ = "1.0.0"
__author__ = "Hackathon Engineering Team"
