"""
Fault-Tolerant Local Storage Engine for Blood Donation Camp Register.
Handles thread-safe & OS-locked JSON, CSV, and indexed SQLite persistence,
with corrupted file recovery, atomic writes, and automated backups.
"""

import os
import json
import csv
import shutil
import sqlite3
import datetime
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import List, Tuple, Optional, Dict, Any
from .models import DonorRecord

if os.name == "nt":
    import msvcrt
else:
    import fcntl


class StorageManager:
    """
    Manages persistent storage with thread-safe & OS-level file locking,
    SQLite B-Tree indexing, and automated corruption detection/recovery.
    """

    def __init__(self, data_dir: Optional[str] = None):
        if data_dir:
            self.data_dir = Path(data_dir)
        else:
            self.data_dir = Path(__file__).resolve().parent.parent / "data"

        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "donors.json"
        self.csv_path = self.data_dir / "donors.csv"
        self.db_path = self.data_dir / "donors_index.db"
        self.lock_path = self.data_dir / ".donors.lock"
        self.audit_log_path = self.data_dir / "audit_log.txt"

        self._thread_lock = threading.RLock()
        self._ensure_storage_exists()

    @contextmanager
    def _acquire_lock(self):
        """Thread-safe and cross-platform OS advisory file lock for concurrent access."""
        with self._thread_lock:
            lock_file = open(self.lock_path, "a+", encoding="utf-8")
            try:
                if os.name == "nt":
                    lock_file.seek(0)
                    msvcrt.locking(lock_file.fileno(), msvcrt.LK_LOCK, 1)
                else:
                    fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
                yield
            finally:
                try:
                    if os.name == "nt":
                        lock_file.seek(0)
                        msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
                    else:
                        fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
                except OSError:
                    pass
                lock_file.close()

    def _ensure_storage_exists(self) -> None:
        """Create empty clean storage files and SQLite schema if they do not exist."""
        with self._acquire_lock():
            if not self.json_path.exists():
                self._write_clean_json([])
            if not self.csv_path.exists():
                self._write_clean_csv([])
            self._init_sqlite_schema()

    def _init_sqlite_schema(self) -> None:
        """Initialize SQLite indexed mirror table for O(log N) queries."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS donors (
                    donor_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    age INTEGER NOT NULL,
                    gender TEXT NOT NULL,
                    blood_group TEXT NOT NULL,
                    phone TEXT NOT NULL,
                    weight_kg REAL NOT NULL,
                    hemoglobin_g_dl REAL NOT NULL,
                    registration_date TEXT NOT NULL,
                    status TEXT NOT NULL,
                    deferral_reason TEXT,
                    units_donated INTEGER DEFAULT 0
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_donors_bg ON donors(blood_group)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_donors_status ON donors(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_donors_phone ON donors(phone)")
            conn.commit()

    def _sync_sqlite(self, records: List[DonorRecord]) -> None:
        """Synchronize records into the indexed SQLite mirror atomically."""
        self._init_sqlite_schema()
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM donors")
            conn.executemany(
                """
                INSERT INTO donors (
                    donor_id, name, age, gender, blood_group, phone,
                    weight_kg, hemoglobin_g_dl, registration_date, status,
                    deferral_reason, units_donated
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    (
                        r.donor_id, r.name, r.age, r.gender, r.blood_group, r.phone,
                        r.weight_kg, r.hemoglobin_g_dl, r.registration_date, r.status,
                        r.deferral_reason, r.units_donated
                    )
                    for r in records
                ]
            )
            conn.commit()

    def query_indexed(
        self,
        blood_group: Optional[str] = None,
        status: Optional[str] = None,
        phone: Optional[str] = None
    ) -> List[DonorRecord]:
        """Perform database-indexed lookup using SQLite B-Tree indexes."""
        clauses = []
        params: List[Any] = []
        if blood_group:
            clauses.append("blood_group = ?")
            params.append(blood_group.strip().upper())
        if status:
            clauses.append("status = ?")
            params.append(status.strip().capitalize())
        if phone:
            clauses.append("phone = ?")
            params.append(phone.strip())

        sql = "SELECT donor_id, name, age, gender, blood_group, phone, weight_kg, hemoglobin_g_dl, registration_date, status, deferral_reason, units_donated FROM donors"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)

        with self._acquire_lock():
            if not self.db_path.exists():
                return []
            with sqlite3.connect(self.db_path) as conn:
                rows = conn.execute(sql, params).fetchall()
                return [
                    DonorRecord(
                        donor_id=row[0], name=row[1], age=row[2], gender=row[3],
                        blood_group=row[4], phone=row[5], weight_kg=row[6],
                        hemoglobin_g_dl=row[7], registration_date=row[8],
                        status=row[9], deferral_reason=row[10] or "", units_donated=row[11]
                    )
                    for row in rows
                ]

    def _write_clean_json(self, records: List[Dict[str, Any]]) -> None:
        with open(self.json_path, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2, ensure_ascii=False)

    def _write_clean_csv(self, records: List[DonorRecord]) -> None:
        headers = [
            "donor_id", "name", "age", "gender", "blood_group",
            "phone", "weight_kg", "hemoglobin_g_dl",
            "registration_date", "status", "deferral_reason", "units_donated"
        ]
        with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            for r in records:
                writer.writerow(r.to_dict())

    def load_all_donors(self) -> Tuple[List[DonorRecord], Optional[str]]:
        """
        Loads all donors from JSON storage under file lock.
        If file is missing or corrupted (JSONDecodeError), automatically creates
        a timestamped recovery backup and initializes a clean dataset.
        Returns: (records, warning_message_or_None)
        """
        with self._acquire_lock():
            if not self.json_path.exists():
                self._write_clean_json([])
                return [], None

            try:
                with open(self.json_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if not content:
                        self._write_clean_json([])
                        return [], None
                    data = json.loads(content)

                if not isinstance(data, list):
                    raise ValueError("JSON root element must be a list of donor records.")

                records: List[DonorRecord] = []
                for item in data:
                    if isinstance(item, dict):
                        records.append(DonorRecord.from_dict(item))

                self._sync_sqlite(records)
                return records, None

            except (json.JSONDecodeError, ValueError) as err:
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                corrupt_backup = self.data_dir / f"donors_corrupt_{timestamp}.json.bak"
                shutil.copyfile(self.json_path, corrupt_backup)

                self._write_clean_json([])
                self._sync_sqlite([])
                warn_msg = (
                    f"STORAGE ALERT: Corrupted JSON detected ({type(err).__name__}). "
                    f"Archived corrupted file to '{corrupt_backup.name}' and initialized clean register."
                )
                self.log_audit("CORRUPTION_RECOVERY", warn_msg)
                return [], warn_msg

            except Exception as e:
                warn_msg = f"Unexpected error reading storage: {str(e)}"
                self.log_audit("ERROR", warn_msg)
                return [], warn_msg

    def save_all_donors(self, records: List[DonorRecord]) -> bool:
        """
        Saves donor list atomically to JSON, syncs CSV, and updates SQLite indexes
        under thread-safe and OS-level file locking.
        """
        with self._acquire_lock():
            temp_json = self.data_dir / f"donors_temp_{datetime.datetime.now().timestamp()}.tmp"
            try:
                dict_data = [r.to_dict() for r in records]
                with open(temp_json, "w", encoding="utf-8") as f:
                    json.dump(dict_data, f, indent=2, ensure_ascii=False)

                os.replace(temp_json, self.json_path)
                self._write_clean_csv(records)
                self._sync_sqlite(records)
                return True
            except Exception as e:
                if temp_json.exists():
                    try:
                        temp_json.unlink()
                    except OSError:
                        pass
                self.log_audit("SAVE_ERROR", f"Failed saving records: {str(e)}")
                return False

    def generate_next_donor_id(self, existing_records: List[DonorRecord]) -> str:
        """Generates sequential ID: DON-YYYYMMDD-####"""
        today_str = datetime.datetime.now().strftime("%Y%m%d")
        prefix = f"DON-{today_str}-"
        highest_seq = 0

        for r in existing_records:
            if r.donor_id.startswith(prefix):
                try:
                    seq_part = int(r.donor_id.replace(prefix, ""))
                    if seq_part > highest_seq:
                        highest_seq = seq_part
                except ValueError:
                    pass

        return f"{prefix}{highest_seq + 1:04d}"

    def log_audit(self, action: str, details: str) -> None:
        """Append an event to the local audit trail safely."""
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] [{action.upper()}] {details}\n"
        try:
            with self._thread_lock:
                with open(self.audit_log_path, "a", encoding="utf-8") as f:
                    f.write(entry)
        except OSError:
            pass
