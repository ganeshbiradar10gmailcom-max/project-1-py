"""
Comprehensive Unit Test Suite for Blood Donation Camp Register.
Tests validation, clinical eligibility, storage resilience, analytics, and bulk import.
Uses Python standard library `unittest`.
"""

import unittest
import tempfile
import shutil
import json
from pathlib import Path

from src.models import DonorRecord, BloodGroup, DonorStatus
from src.validators import (
    validate_name, validate_age, validate_gender, validate_blood_group,
    validate_phone, validate_weight, validate_hemoglobin, evaluate_donor_eligibility
)
from src.storage import StorageManager
from src.business_logic import (
    CampAnalyticsEngine, RecordSearchFilter,
    IndexedDonorCache, BloodAllocationOptimizer
)
from src.importer import BulkCSVImporter
from src.exporters import CampReportExporter


class TestDefensiveValidation(unittest.TestCase):
    """Verifies that all input constraints and medical checks are strictly enforced."""

    def test_name_validation(self):
        # Valid names
        self.assertTrue(validate_name("Aarav Sharma")[0])
        self.assertTrue(validate_name("Mary-Jane O'Connor")[0])

        # Invalid names
        self.assertFalse(validate_name("")[0])
        self.assertFalse(validate_name("A")[0])
        self.assertFalse(validate_name("John123")[0])
        self.assertFalse(validate_name("   ")[0])

    def test_age_validation(self):
        self.assertTrue(validate_age(18)[0])
        self.assertTrue(validate_age(65)[0])
        self.assertTrue(validate_age("30")[0])

        self.assertFalse(validate_age("twenty")[0])
        self.assertFalse(validate_age(0)[0])
        self.assertFalse(validate_age(150)[0])

    def test_blood_group_validation(self):
        for bg in ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]:
            self.assertTrue(validate_blood_group(bg)[0])
            self.assertTrue(validate_blood_group(bg.lower())[0])

        self.assertFalse(validate_blood_group("C+")[0])
        self.assertFalse(validate_blood_group("")[0])
        self.assertFalse(validate_blood_group("O positive")[0])

    def test_phone_validation(self):
        self.assertTrue(validate_phone("9876543210")[0])
        self.assertTrue(validate_phone("+919876543210")[0])
        self.assertTrue(validate_phone("9876-543-210")[0])

        self.assertFalse(validate_phone("12345")[0])
        self.assertFalse(validate_phone("abcdefghij")[0])
        self.assertFalse(validate_phone("")[0])

    def test_weight_and_hemoglobin_validation(self):
        self.assertTrue(validate_weight(50.0)[0])
        self.assertFalse(validate_weight(10.0)[0])  # too low
        self.assertFalse(validate_weight("heavy")[0])

        self.assertTrue(validate_hemoglobin(13.5)[0])
        self.assertFalse(validate_hemoglobin(1.5)[0])   # clinically impossible
        self.assertFalse(validate_hemoglobin(30.0)[0])

    def test_clinical_eligibility_logic(self):
        # Eligible donor
        status, reason = evaluate_donor_eligibility(age=25, weight_kg=65.0, hemoglobin_g_dl=14.0)
        self.assertEqual(status, DonorStatus.ELIGIBLE.value)
        self.assertEqual(reason, "")

        # Underage donor
        status, reason = evaluate_donor_eligibility(age=17, weight_kg=60.0, hemoglobin_g_dl=14.0)
        self.assertEqual(status, DonorStatus.DEFERRED.value)
        self.assertIn("Underage", reason)

        # Underweight donor
        status, reason = evaluate_donor_eligibility(age=25, weight_kg=48.0, hemoglobin_g_dl=14.0)
        self.assertEqual(status, DonorStatus.DEFERRED.value)
        self.assertIn("Underweight", reason)

        # Low Hemoglobin donor
        status, reason = evaluate_donor_eligibility(age=25, weight_kg=55.0, hemoglobin_g_dl=11.5)
        self.assertEqual(status, DonorStatus.DEFERRED.value)
        self.assertIn("Low Hemoglobin", reason)

        # Compound deferral reasons
        status, reason = evaluate_donor_eligibility(age=16, weight_kg=45.0, hemoglobin_g_dl=10.0)
        self.assertEqual(status, DonorStatus.DEFERRED.value)
        self.assertIn("Underage", reason)
        self.assertIn("Underweight", reason)
        self.assertIn("Low Hemoglobin", reason)


class TestStorageFaultTolerance(unittest.TestCase):
    """Verifies persistence stability, atomic writes, and corrupted file auto-recovery."""

    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.storage = StorageManager(self.test_dir)

    def tearDown(self):
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_save_and_reload(self):
        test_donor = DonorRecord(
            donor_id="DON-20261122-0001",
            name="Test User",
            age=25,
            gender="Male",
            blood_group="O+",
            phone="9812345678",
            weight_kg=65.0,
            hemoglobin_g_dl=14.5,
            registration_date="2026-11-22 10:00:00",
            status="Eligible",
            deferral_reason="",
            units_donated=0
        )
        self.storage.save_all_donors([test_donor])

        loaded, warn = self.storage.load_all_donors()
        self.assertIsNone(warn)
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].donor_id, "DON-20261122-0001")
        self.assertEqual(loaded[0].name, "Test User")

    def test_corrupted_json_auto_recovery(self):
        # Intentionally write garbage to JSON file
        with open(self.storage.json_path, "w", encoding="utf-8") as f:
            f.write("{This is corrupted unparseable JSON content!@#$%^")

        loaded, warn = self.storage.load_all_donors()
        self.assertEqual(len(loaded), 0)
        self.assertIsNotNone(warn)
        self.assertIn("STORAGE ALERT: Corrupted JSON detected", warn)

        # Verify a .bak archive file was created
        backups = list(Path(self.test_dir).glob("donors_corrupt_*.json.bak"))
        self.assertTrue(len(backups) >= 1)


class TestAnalyticsAndReporting(unittest.TestCase):
    """Verifies aggregation metrics, blood group tallies, and report exports."""

    def setUp(self):
        self.records = [
            DonorRecord("DON-001", "Alice", 20, "Female", "O+", "9800000001", 60.0, 14.0, "2026-11-22", "Donated", "", 1),
            DonorRecord("DON-002", "Bob", 30, "Male", "O+", "9800000002", 70.0, 15.0, "2026-11-22", "Eligible", "", 0),
            DonorRecord("DON-003", "Charlie", 40, "Male", "A+", "9800000003", 80.0, 14.5, "2026-11-22", "Donated", "", 1),
            DonorRecord("DON-004", "Daisy", 17, "Female", "O-", "9800000004", 45.0, 11.0, "2026-11-22", "Deferred", "Underage", 0),
        ]

    def test_blood_group_counts(self):
        counts = CampAnalyticsEngine.get_counts_by_blood_group(self.records)
        self.assertEqual(counts["O+"]["total"], 2)
        self.assertEqual(counts["O+"]["donated"], 1)
        self.assertEqual(counts["O+"]["eligible"], 1)
        self.assertEqual(counts["A+"]["total"], 1)
        self.assertEqual(counts["O-"]["deferred"], 1)
        self.assertEqual(counts["B+"]["total"], 0)

    def test_summary_metrics(self):
        summary = CampAnalyticsEngine.compute_camp_summary(self.records)
        self.assertEqual(summary["total_registrations"], 4)
        self.assertEqual(summary["total_donated"], 2)
        self.assertEqual(summary["total_eligible"], 1)
        self.assertEqual(summary["total_deferred"], 1)
        self.assertEqual(summary["total_units_collected"], 2)
        self.assertEqual(summary["deferral_rate_pct"], 25.0)

    def test_search_and_filter(self):
        # By Blood Group
        o_pos = RecordSearchFilter.filter_records(self.records, blood_group="O+")
        self.assertEqual(len(o_pos), 2)

        # By Status
        donated = RecordSearchFilter.filter_records(self.records, status="Donated")
        self.assertEqual(len(donated), 2)

        # By Keyword
        bob = RecordSearchFilter.filter_records(self.records, keyword="Bob")
        self.assertEqual(len(bob), 1)
        self.assertEqual(bob[0].name, "Bob")

    def test_indexed_cache_and_sqlite_query(self):
        cache = IndexedDonorCache(self.records)
        self.assertEqual(cache.get_by_id("DON-001").name, "Alice")
        self.assertEqual(len(cache.get_by_phone("9800000002")), 1)
        self.assertEqual(len(cache.get_by_blood_group("O+")), 2)

        with tempfile.TemporaryDirectory() as tmp_dir:
            sm = StorageManager(tmp_dir)
            self.assertTrue(sm.save_all_donors(self.records))
            indexed_o_pos = sm.query_indexed(blood_group="O+", status="Donated")
            self.assertEqual(len(indexed_o_pos), 1)
            self.assertEqual(indexed_o_pos[0].donor_id, "DON-001")

    def test_blood_allocation_optimizer(self):
        # Request 2 units of A+: 1 A+ collected + 1 O+ collected (exact match first, O- untouched)
        plan = BloodAllocationOptimizer.allocate_units(self.records, "A+", 2)
        self.assertEqual(plan["fulfillment_status"], "FULFILLED")
        self.assertEqual(plan["units_allocated"], 2)
        self.assertFalse(plan["used_universal_o_neg_fallback"])
        self.assertEqual(plan["allocations"][0]["source_group"], "A+")
        self.assertEqual(plan["allocations"][1]["source_group"], "O+")


if __name__ == "__main__":
    unittest.main()
